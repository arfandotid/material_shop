<?php
defined('BASEPATH') or exit('No direct script access allowed');

class User extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        is_logged_in();
        $this->load->model('MainModel', 'main');
        $this->form_validation->set_error_delimiters('<small class="text-danger">', '</small>');
    }

    public function index()
    {
        $data['title'] = "User";
        $data['user'] = $this->main->get('user');

        template_view('user/index', $data);
    }

    private function _validasi()
    {
        $this->form_validation->set_rules('');
    }

    public function add()
    {
        $data['title'] = "User";
        $data['idUser'] = $this->main->newUserId();

        $this->_validasi();
        if ($this->form_validation->run() == false) {
            template_view('user/add', $data);
        } else {
            $input = $this->input->post(null, true);
            var_dump($input);
            die;
        }
    }
}
