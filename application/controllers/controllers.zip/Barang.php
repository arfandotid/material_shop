<?php
defined('BASEPATH') or exit('No direct script access allowed');


class Barang extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        is_logged_in();
        $this->load->model('MainModel', 'main');
        $this->form_validation->set_error_delimiters('<small class="text-danger">', '</small>');
    }

    public function index()
    {
        $data['title'] = "Barang";
        $data['barang'] = $this->main->get('barang');

        template_view('barang/index', $data);
    }

    private function _validasi()
    {
        $this->form_validation->set_rules('namaBarang', 'Nama Barang', 'required|trim');
        $this->form_validation->set_rules('idKategori', 'Kategori', 'required');
        $this->form_validation->set_rules('stok', 'Stok', 'required|numeric|trim');
        $this->form_validation->set_rules('harga', 'harga', 'required|numeric|trim');
    }

    public function add()
    {
        $kdBarang = generate_id("B", "barang", "kdBarang", date('y'));

        $data['title'] = "Barang";
        $data['kategori'] = $this->main->get('kategori');
        $data['kdBarang'] = $kdBarang;

        $this->_validasi();
        if ($this->form_validation->run() == false) {
            template_view('barang/add', $data);
        } else {
            $input = $this->input->post(null, true);
            $input['kdBarang'] = $kdBarang;

            $this->main->insert('barang', $input);
            redirect('barang');
        }
    }
}
