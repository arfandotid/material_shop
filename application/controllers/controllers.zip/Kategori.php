<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Kategori extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        is_logged_in();
        $this->load->model('MainModel', 'main');
        $this->form_validation->set_error_delimiters('<small class="text-danger">', '</small>');
    }

    public function index()
    {
        $data['title'] = "Kategori";
        $data['kategori'] = $this->main->get('kategori');

        template_view('kategori/index', $data);
    }

    private function _validasi()
    {
        $this->form_validation->set_rules('namaKategori', 'Nama Kategori', 'required|trim');
    }

    public function add()
    {
        $data['title'] = "Kategori";

        $this->_validasi();
        if ($this->form_validation->run() == false) {
            template_view('kategori/add', $data);
        } else {
            $input = $this->input->post(null, true);

            $this->main->insert('kategori', $input);
            redirect('kategori');
        }
    }

    public function edit($getId)
    {
        $id = encode_php_tags($getId);
        $where = ['idKategori' => $id];

        $data['title'] = 'Kategori';
        $data['kategori'] = $this->main->get_where('kategori', $where);

        $this->_validasi();
        if ($this->form_validation->run() == false) {
            template_view('kategori/edit', $data);
        } else {
            $input = $this->input->post(null, true);

            $this->main->update('kategori', $input, $where);
            redirect('kategori');
        }
    }

    public function hapus($getId)
    {
        $id = encode_php_tags($getId);
        $where = ['idKategori' => $id];

        $this->main->delete('kategori', $where);
        redirect('kategori');
    }
}
